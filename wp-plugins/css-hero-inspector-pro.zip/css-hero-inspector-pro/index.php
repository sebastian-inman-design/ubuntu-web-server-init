<?php

/* Plugin Name: CSS Hero Inspector PRO
Plugin URI: csshero.org
Description: CSS Hero Inspector Tool: Live display CSS Hero applied rules. Requires CSS Hero 2.1+
Version: 1.0b1
Plugin Author:  
Author URI: CSS Hero Team
*/ 

function hero_activate_inspector() {
	$hero_inspector_version = 'pro-1.0';
	$hero_inspector_js = '//csshero.org/production/inspector/'.$hero_inspector_version.'/inspector.js';
	$hero_inspector_css	='//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/inspector.css';
	$code_mirror_css ='//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/codemirror/codemirror.css';
	$code_mirror_theme_css ='//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/codemirror/herotheme.css';
	$code_mirror_js	='//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/codemirror/codemirror.js';
	$cssom_parser_js = '//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/cssom/parser.js';
	$code_mirror_addons_js	='//csshero.org/production/inspector/'.$hero_inspector_version.'/assets/codemirror/codemirror_addons.js';
	echo "<script type='text/javascript' src='".$code_mirror_js."'></script><script type='text/javascript' src='".$code_mirror_addons_js."'></script><script type='text/javascript' src='".$hero_inspector_js."'></script><script type='text/javascript' src='".$cssom_parser_js."'></script><link rel='stylesheet' id='learn-css'  href='".$hero_inspector_css."' type='text/css' media='all' /><link rel='stylesheet' id='codemirror'  href='".$code_mirror_css."' type='text/css' media='all' /><link rel='stylesheet' id='hero_inspector_codemirror'  href='".$code_mirror_theme_css."' type='text/css' media='all' />";

} // CHECK IF INSPECTOR IS ON

